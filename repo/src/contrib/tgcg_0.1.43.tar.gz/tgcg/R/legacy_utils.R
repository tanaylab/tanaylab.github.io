symlink_old_fastq_files <- function(){
    a <- get_batch_metadata() %>% 
        distinct(seq_batch_id) %>% 
        mutate(run_date = gsub('nextseq_', '', seq_batch_id),  
               mraid14_dir = glue('/net/mraid14/export/tgdata/users/aviezerl/pbat/results/{gsub("20", "", run_date)}_wgPBAT'), 
               new_dir = glue('/net/mraid14/export/tgdata/db/tgdb/cgdb_fastq/{run_date}'))

    walk2(a$mraid14_dir, a$new_dir, ~ fs::link_create(.x, .y))
}

# add_indexes_to_excel <- function(){
#     batch_metadata <- get_batch_metadata()    
#     plates <- unique(batch_metadata$plate)
#     all_conf <- map(plates, ~ drop_read_yaml(glue('scMethDB/config/{.x}_index.yaml')))
#     batch_metadata  %>% mutate(batch_num = str_extract(amp_batch_id, '(.)$')) %>% select(-illumina_index, -pbat2_index)  %>% left_join(imap_dfr(a, ~.x %>% mutate(plate = .y))  %>% mutate(batch_num = gsub('batch', '', batch)) %>% select(plate, batch_num, illumina_index, pbat2_index))  %>% select(batch, plate, indexes_layout, illumina_index, pbat2_index, everything() ) %>% write_csv('~/temp/bmd.csv')
    
# }