.onLoad <- function(libname, pkgname) {
    sc5mc_pipeline_init()
}