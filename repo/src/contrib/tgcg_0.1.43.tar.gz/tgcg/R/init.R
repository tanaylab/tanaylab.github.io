sc5mc_pipeline_init <- function(params_yaml=system.file('config/tgcg_params.yaml', package='tgcg')){
	suppressWarnings(tgconfig::register_params(params_yaml, package='tgcg'))
    rdrop2::drop_auth(rdstoken=tgconfig::get_param('dropbox_token', package='tgcg'))		
}