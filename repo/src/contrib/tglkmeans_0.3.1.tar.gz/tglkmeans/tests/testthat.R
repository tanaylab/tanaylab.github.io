library(testthat)
library(tglkmeans)
library(dplyr)
library(ggplot2)
library(purrr)
library(tgstat)

test_check("tglkmeans")

