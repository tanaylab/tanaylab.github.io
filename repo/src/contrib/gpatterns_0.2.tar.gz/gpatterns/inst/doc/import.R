## ---- eval = FALSE-------------------------------------------------------
#  gpatterns.bissli2(r1_fastq = 'Breast_2460_1.3_R1/fastq/Breast_2460_1.3_R1.fastq', r2_fastq = 'Breast_2460_1.3_R1/fastq/Breast_2460_1.3_R2.fastq', out_bam = 'Breast_2460_1.3_R1/bam/Breast_2460_1.3.bam', genome_seq = "/net/mraid14/export/data/db/tgdb/hg19/seq", genome_type="ct_ga", bissli2_idx = "/net/mraid14/export/data/tools/bissli2/hg19/hg19")

## ---- eval = FALSE-------------------------------------------------------
#  gpatterns.import_from_bam('bam/Breast_2460_1.3.bam', workdir='Breast_2460_1.3_R1', trim=1, cgs_mask_file='/net/mraid14/export/tgdata/users/aviezerl/proj/gpatterns_nugget/msp1_stickey_ends', frag_intervs='intervs.msp1.fid', rm_off_target=T, maxdist=4, use_sge=F, parallel=TRUE, paired_end=TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  gpatterns.import_from_tidy_cpgs(tidy_cpgs="Breast_2460_1.3_R1/tidy_cpgs", track="gpatterns_nugget.Breast_2460_1.3_R1", description="", groot="/home/aviezerl/hg19", max_span=600, parallel=TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  pat_space <- gpatterns.intervs_to_pat_space(tracks, intervals='intervs.msp1.fid', adjacent=TRUE, pat_len=5, parallel=TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  purrr::walk(tracks, ~ gpatterns.create_patterns_track(track = .x, description = paste0('patterns of ', .x), pat_space=pat_space, max_missing=0))

