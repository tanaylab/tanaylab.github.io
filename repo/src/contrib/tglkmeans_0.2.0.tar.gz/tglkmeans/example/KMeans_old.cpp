#include <algorithm>

#include "port.h"
BASE_CC_FILE
#include "KMeans.h"
#include "AParamStat.h"
#include "Random.h"

#ifdef __GXX_EXPERIMENTAL_CXX0X__
#ifndef isnan
#define isnan ::isnan
#endif
#endif

void KMeansCenterBase::report_meta_data_header(ostream &out)
{
    //do nothing by default
}

void KMeansCenterBase::report_meta_data(ostream &out, const vector<float> &v)
{
    //do nothing by default
}

void KMeansCenterMean::init(vector<float> &cent)
{
    m_center = cent;
    m_votes.resize(m_center.size());

    update_center_stats();
}

void KMeansCenterMean::vote(const vector<float> &x, float wgt)
{
    vector<float>::const_iterator x_i = x.begin();
    vector<float>::iterator wgt_i = m_tot_wgt.begin();
    for(vector<float>::iterator v_i = m_votes.begin(); v_i != m_votes.end(); v_i++) {
        if(*x_i != _REAL(MAX)) {
            *v_i += *x_i * wgt;
            *wgt_i += wgt;
        }
        wgt_i++;
        x_i++;
    }
}

void KMeansCenterMean::reset_votes()
{
    fill(m_votes.begin(), m_votes.end(), 0);
    fill(m_tot_wgt.begin(), m_tot_wgt.end(), 0);
}

void KMeansCenterMean::init_to_votes()
{
    vector<float>::iterator v_i = m_votes.begin();
    vector<float>::iterator wgt_i = m_tot_wgt.begin();
    for(vector<float>::iterator c_i = m_center.begin(); c_i != m_center.end(); c_i++) {
        if(*wgt_i != 0) {
            *c_i = *v_i/(*wgt_i);
        } else {
            *c_i = _REAL(MAX);
        }
        v_i++;
        wgt_i++;
    }
    update_center_stats();
}

void KMeansCenterMean::update_center_stats()
{
    //do nothing by default
}
void KMeansCenterMean::report(ostream &out)
{
    for(int i = 0; i < m_center.size(); i++) {
        if(i != 0) {
            out << "\t";
        }
        out << m_center[i];
    }
}

float KMeansCenterMeanEuclid::dist(const vector<float> &x)
{
    vector<float>::const_iterator x_i = x.begin();
    float dist2 = 0;
    float n = 0;
    for(vector<float>::const_iterator c_i = m_center.begin(); c_i != m_center.end(); c_i++) {
        if(*x_i != _REAL(MAX) && *c_i != _REAL(MAX)) {
            dist2 += (*c_i  - *x_i)*(*c_i - *x_i);
            n++;
        }
//		cerr << "dist " << *c_i << " " << *x_i << " tot2 " << dist2 << " n " << n << endl;
        x_i++;
    }
    return(n > 0 ? sqrt(dist2)/n : _REAL(MAX));
};

float KMeansCenterMeanPearson::dist(const vector<float> &x)
{
    vector<float>::const_iterator x_i = x.begin();
    float cov2 = 0;
    float x_v2 = 0;
    float x_e = 0;
    int n = 0;
    for(vector<float>::const_iterator c_i = m_center.begin(); c_i != m_center.end(); c_i++) {
        if(!isnan(*x_i) && *x_i != _REAL(MAX) && *c_i != _REAL(MAX)) {
            cov2 += (*c_i) * (*x_i);
            x_v2 += (*x_i) * (*x_i);
            x_e += (*x_i);
            n++;
        }
        x_i++;
    }
    if(n == 0) {
        return(0);
    }
    x_e /= n;
    float cov = cov2/n - x_e * m_center_e;

    float x_v = x_v2/n - x_e * x_e;
    if(x_v == 0) {
        return(0);
    }
    return(cov/sqrt(m_center_v * x_v));
};

void KMeansCenterMeanPearson::update_center_stats()
{
    float c_e = 0;
    float c_e2 = 0;
    float n = 0;
    for(vector<float>::iterator c_i = m_center.begin(); c_i != m_center.end(); c_i++) {
        if(*c_i != _REAL(MAX)) {
            c_e += *c_i;
            c_e2 += (*c_i)*(*c_i);
            n++;
        }
    }
    m_center_e = c_e/n;
    m_center_v = c_e2/n - m_center_e*m_center_e;
}

//We could have save the ranking of the center and cut some running time here.
float KMeansCenterMeanSpearman::dist(const vector<float> &x)
{
    double pv;
    return(-spearman(x, m_center, m_rank1, m_rank2, pv));
}

KMeans::KMeans(const vector<vector<float> > &data, int k, vector<KMeansCenterBase *> &centers) :
        m_k(k),
        m_centers(centers),
        m_assignment(data.size(), -1),
        m_data(data)
{
}

void KMeans::cluster(int max_iter, float min_assign_change_fraction)
{
    cerr << "KMEans: will generate seeds" << endl;
    generate_seeds();

    int iter = 0;
    m_changes = 0;

    cerr << "KMEans: reassign after init" << endl;
    reassign();

    while(iter < max_iter && m_changes/m_assignment.size() > min_assign_change_fraction) {
        cerr << "KMEans: iter " << iter << endl;
        m_changes = 0;
        update_centers();
        reassign();
        iter++;
        cerr << "KMEans: iter " << iter << " changed " << m_changes << endl;
    }
}

void KMeans::generate_seeds()
{
    cerr << "KMeans into generate seeds" << endl;
    for(int i = 0; i < m_k; i++) {
        cerr << "at seed " << i << endl;
        m_min_dist.resize(0);
        //compute minimal distance from centers
        //select next seed by sampling
        int seed_i = -1;
        if(i == 0) {
            seed_i = Random::fraction() * m_data.size();
        } else {
            update_min_distance(i);
            cerr << "done update min distance" << endl;
            sort(m_min_dist.begin(), m_min_dist.end());
            //select from 1/k of the data which is in the 1-1/2k quantile of the min distance
            int to_i = int(m_min_dist.size() * (1 - 1/(2*m_k)));
            int from_i = to_i - int(m_data.size()/m_k);
            cerr << "seed range " << from_i << " " << to_i << endl;
            if(from_i < 0) {
                from_i = 0;
            }
            int rnd_i = from_i + int(Random::fraction()*(to_i - from_i));
            seed_i = m_min_dist[rnd_i].second;
            cerr << "picked up " << seed_i << " dist was " << m_min_dist[rnd_i].first << endl;
        }

        add_new_core(seed_i, i);
    }
}


void KMeans::update_min_distance(int cur_k)
{
    vector<int>::iterator assign_i = m_assignment.begin();
    int samp_i = 0;
    for(vector<vector<float> >::const_iterator data_i = m_data.begin(); data_i != m_data.end(); data_i++) {
        if(*assign_i != -1) {
            samp_i++;
            assign_i++;
            continue;
        }
        float best_dist = _REAL(MAX);
        int id_i = 0;
        for(vector<KMeansCenterBase *>::iterator cent_i = m_centers.begin(); id_i < cur_k; cent_i++) {
            float dist = (*cent_i)->dist(*data_i);
            if(dist < best_dist) {
                best_dist = dist;
            }
            id_i++;
        }
        m_min_dist.push_back(pair<float, int>(best_dist, samp_i));

        samp_i++;
        assign_i++;
    }
}

void KMeans::add_new_core(int seed_i, int center_i)
{
    cerr << "add new core from " << seed_i << " to " << center_i << endl;
    m_centers[center_i]->reset_votes();
    m_centers[center_i]->vote(m_data[seed_i], 1);
    m_centers[center_i]->init_to_votes();

    m_core_dist.resize(0);

    vector<int>::iterator assign_i = m_assignment.begin();
    int samp_i = 0;
    for(vector<vector<float> >::const_iterator data_i = m_data.begin(); data_i != m_data.end(); data_i++) {
        if(*assign_i == -1) {
            float dist = m_centers[center_i]->dist(*data_i);
            m_core_dist.push_back(pair<float, int>(dist, samp_i));
        }
        samp_i++;
        assign_i++;
    }
    sort(m_core_dist.begin(), m_core_dist.end());

    int to_add_n = int(m_data.size()/(2*m_k));
    int count = 0;
    m_centers[center_i]->reset_votes();
    for(vector<pair<float,int> >::iterator i = m_core_dist.begin(); count < to_add_n; i++) {
        m_centers[center_i]->vote(m_data[i->second], 1);
        m_assignment[i->second] = center_i;
        count++;
    }
    m_centers[center_i]->init_to_votes();
}

void KMeans::update_centers()
{
    for(int i = 0; i < m_k; i++) {
        m_centers[i]->init_to_votes();
        m_centers[i]->reset_votes();
    }
}

void KMeans::reassign()
{
    vector<int>::iterator assign_i = m_assignment.begin();

    for(vector<vector<float> >::const_iterator data_i = m_data.begin(); data_i != m_data.end(); data_i++) {
        int id_i = 0;
        float best_dist = _REAL(MAX);
        int best_id_i = -1;
        for(vector<KMeansCenterBase *>::iterator cent_i = m_centers.begin(); cent_i != m_centers.end(); cent_i++) {
            float dist = (*cent_i)->dist(*data_i);
            if(dist < best_dist) {
                best_dist = dist;
                best_id_i = id_i;
            }
            id_i++;
        }
        ASSERT(best_id_i != -1, "Cannot assign any center to element " << data_i-m_data.begin() << " all dist == real(max)");
        if(*assign_i != best_id_i) {
            *assign_i = best_id_i;
            m_changes++;
        }
        m_centers[best_id_i]->vote(*data_i, 1);
        assign_i++;
    }
}

void KMeans::report_centers(ostream &center_tab)
{
    for(int i = 0; i < m_k; i++) {
        center_tab << i << "\t";
        m_centers[i]->report(center_tab);
        center_tab << "\n";
    }
}

void KMeans::report_assignment(vector<string> &row_names, ostream &assign_tab)
{
    assign_tab << "id\tclust";
    m_centers[0]->report_meta_data_header(assign_tab);
    assign_tab << "\n";
    for(int i = 0; i < m_data.size(); i++) {
        assign_tab << row_names[i] << "\t" << m_assignment[i];

        m_centers[m_assignment[i]]->report_meta_data(assign_tab, m_data[i]);

        assign_tab << "\n";
    }
}
