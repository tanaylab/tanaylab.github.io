
#' Get current batch metadata config table
#' 
#' @param file relative path of the metadata file
#' 
#' @examples
#' 
#' metadata <- get_batch_metadata()
#' metadata
#' 
#' @export
get_batch_metadata <- function(file = 'scMethDB/scPBAT_annotation.xlsx'){
    metadata_fn <- tempfile()
    drop_download(file, metadata_fn, overwrite = TRUE, verbose=FALSE, progress=FALSE)
    return(readxl::read_xlsx(metadata_fn)[-1, ])
}

dir_rw <- function(dir){
    exists <- fs::dir_exists(dir) || fs::link_exists(dir)
    return(exists &&  fs::file_access(dir, mode = c('read', 'write', 'execute')))
}

dir_r <- function(dir){
    exists <- fs::dir_exists(dir) || fs::link_exists(dir)
    return(exists &&  fs::file_access(dir, mode = c('read', 'execute')))
}

dir_copy_or_link <- function(path, new_path){    
    orig_device <- fs::file_info(path)$device_id 
    dest_device <- fs::file_info(fs::path_dir(new_path))$device_id
    if (is.na(orig_device) || is.na(dest_device) || orig_device != dest_device){
        fs::dir_copy(path, new_path)
    } else {
        fs::link_create(path, new_path)
    }
}

drop_read_yaml <- function(file){
    fn <- tempfile()
    drop_download(file, fn, overwrite = TRUE, verbose=FALSE, progress=FALSE)   
    return(yaml::read_yaml(fn))
}

assert_batch_exists <- function(batch, batch_metadata){
    if (!(batch %in% batch_metadata$batch)){
        stop(glue('{batch} does not appear in the excel metadata. Please make sure to fill the entries in scMethDB/scPBAT_annotation.xlsx and try again.'))
    }
}

assert_plate_exists <- function(plate, batch_metadata){
    if (!(plate %in% batch_metadata$plate)){
        stop(glue('{plate} does not appear in the excel metadata. Please make sure to fill the entries in scMethDB/scPBAT_annotation.xlsx and try again.'))
    }
}

config_exists <- function(plate){
    return(drop_exists(glue('scMethDB/config/{plate}_index.yaml')))    
}

assert_layout_exists <- function(version){
    config_file_dropbox <- glue('scMethDB/layouts/{version}.yaml')
    if (!drop_exists(config_file_dropbox)){
        stop(glue('Indexes layout config file does not exist. Please make sure to create the following file: {config_file_dropbox}'))
    }
}

assert_defaults_exists <- function(env_name){
    config_file_dropbox <- glue('scMethDB/env_config/{env_name}.yaml')
    if (!drop_exists(config_file_dropbox)){
        stop(glue('environment config file does not exist. Please make sure to create the following file: {config_file_dropbox}'))
    }
}

#' Show a message colored red
#' @export
red_message <- function(msg, log=TRUE){  
    msg <- red(glue(msg, .envir = parent.frame(1)))
    if (log){
        loginfo(msg)    
    }
    message(msg)
}

#' Show a message colored blue
#' @export
blue_message <- function(msg, log=TRUE){ 
    msg <- blue(glue(msg, .envir = parent.frame(1)))
    if (log){
        loginfo(msg)    
    }
    message(msg)
}
