library(testthat)
library(tglkmeans)

test_check("tglkmeans")
