#ifndef stdalg_alg_KMeans_h
#define stdalg_alg_KMeans_h 1

#include <vector>

class KMeansCenterBase
{
public:
	virtual float dist(const vector<float> &v) = 0;
	
	virtual void vote(const vector<float> &v, float wgt) = 0;
	virtual void reset_votes() = 0;
	virtual void init_to_votes() = 0;
	
	virtual void report_meta_data_header(ostream &out);
	virtual void report_meta_data(ostream &out, const vector<float> &v);
	
	virtual void report(ostream &out) = 0;
};

class KMeansCenterMean : public KMeansCenterBase {
	
protected:

	vector<float> m_center;
	
	vector<float> m_votes;
	vector<float> m_tot_wgt;
	
public:

	KMeansCenterMean(int dim) :
		m_center(dim, 0),
		m_votes(dim, 0),
		m_tot_wgt(dim, 0)
	{}

	virtual void init(vector<float> &cent);
	virtual void vote(const vector<float> &v, float wgt);
	virtual void reset_votes();  //tot = 0, votes = 0
	virtual void init_to_votes(); //center = votes/tot
	virtual void update_center_stats();
	virtual void report(ostream &out);
};

class KMeansCenterMeanEuclid : public KMeansCenterMean {
public:
	KMeansCenterMeanEuclid(int dim) :
		KMeansCenterMean(dim)
	{}
	virtual float dist(const vector<float> &v);
};

class KMeansCenterMeanPearson : public KMeansCenterMean {

protected:
	
	float m_center_e;
	float m_center_v;
	
public:
	KMeansCenterMeanPearson(int dim) :
		KMeansCenterMean(dim)
	{}
	virtual float dist(const vector<float> &v);
	virtual void update_center_stats();
};

class KMeansCenterMeanSpearman : public KMeansCenterMean {
protected:
	vector<float> m_rank1;
	vector<float> m_rank2;
public:
	KMeansCenterMeanSpearman(int dim) :
		m_rank1(dim),
		m_rank2(dim),
		KMeansCenterMean(dim)
	{}
	
	virtual float dist(const vector<float> &v);
};

class KMeans
{

protected:

	int m_k;
	
	vector<KMeansCenterBase *> m_centers;
	
	vector<int> m_assignment;
	
	vector<pair<float, int> > m_min_dist;
	vector<pair<float, int> > m_core_dist;
	
	const vector<vector<float> > &m_data;
	
	float m_changes;
	
public:

	KMeans(const vector<vector<float> > &data, int k, vector<KMeansCenterBase *> &centers);

	void cluster(int max_iter, float min_delta_assign);

	void update_min_distance(int max_k);
	void add_new_core(int seed_i, int center_i);

	void generate_seeds();
	void update_centers();
	void reassign();
	
	void report_centers(ostream &center_tab);
	void report_assignment(vector<string> &row_names, ostream &assign_tab);
};

#endif

