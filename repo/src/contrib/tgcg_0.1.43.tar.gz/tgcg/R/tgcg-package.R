#' tgcg
#' 
#' @name tgcg
#' @docType package
#' 
#' @import dplyr
#' @import purrr
#' @import tidyr
#' @import fs
#' @import rdrop2
#' @importFrom gpatterns fread
#' @importFrom crayon red
#' @importFrom crayon blue
#' @importFrom tibble has_name
#' @importFrom glue glue
#' @importFrom tibble as.tibble
#' @importFrom logging loginfo
#' @importFrom logging logwarn
#' @importFrom logging logerror
#' @importFrom data.table fwrite
NULL
