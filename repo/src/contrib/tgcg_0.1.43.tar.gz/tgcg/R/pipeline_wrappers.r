#' Run sc5mc pipeline on a sequencing batch
#' 
#' @param batch batch id (should correspond to one or more lines of 'scMethDB/scPBAT_annotation.xlsx' in the dropbox) 
#' @param db_dir directory of the database in which to process the batch - do not change manually. 
#' @param fastq_db_dir directory of the fastq database in which to process the batch - do not change manually. 
#' @param copy_from_mraid40 copy files from mraid40. If FALSE, the function would prompt the user on whether to copy the files or not.
#' @param email vector of email addresses to which the pipeline would send an email once finished.
#' @param overwrite overwrite previous runs of the pipeline. If TRUE - the previous runs would be deleted. If one or more of the pipeline steps ('demultiplexing', 'mapping' or 'bam2smat') only the files that were created in and after that steps would be deleted.
#' @param force force run (even with errors)
#' 
#' 
#' @return None
#' 
#' @examples 
#' \dontrun{
#' run_pipe_batch('BATCH888', email='my_email@weizmann.ac.il')
#' }
#' 
#' @export
run_pipe_batch <- function(batch, db_dir=tgconfig::get_param('db_dir', package='tgcg'), fastq_db_dir = tgconfig::get_param('fastq_db_dir', package='tgcg'), copy_from_mraid40=FALSE, email=NULL, overwrite=FALSE, force=FALSE){
    batch_metadata <- get_batch_metadata()
    assert_batch_exists(batch, batch_metadata)
    b_metadata <- batch_metadata %>% filter(batch == !! batch)

    plate <- b_metadata$plate[1]    
    run_date <- gsub('nextseq_', '', b_metadata$seq_batch_id[1])    
    indexes_version <- b_metadata$indexes_layout[1]
    batch_dir <- glue('{db_dir}/batches/{batch}')
    raw_fastq_dir <-  glue('{fastq_db_dir}/{run_date}')
    log_file <- glue('{batch_dir}/log')
    b_metadata$capture_probes <- ifelse(b_metadata$capture_probes == 'NA', NA, b_metadata$capture_probes)
    if (any(!is.na(b_metadata$capture_probes))){
        regions <- unique(b_metadata$capture_probes[!is.na(b_metadata$capture_probes)])[1]
        regions <- glue('intervs.captPBAT_probes.{regions}')
    } else {
        regions <- NULL
    }
        
    blue_message('batch: {batch}', log=FALSE)
    blue_message('plate: {plate}', log=FALSE)
    blue_message('run_date: {run_date}', log=FALSE)
    blue_message('indexes_layout: {indexes_version}', log=FALSE)
    blue_message(paste("amp_batches:", paste(unique(b_metadata$amp_batch_id), collapse=', ')), log=FALSE)
    blue_message('output_dir: {batch_dir}', log=FALSE)
    blue_message('raw_fastq_dir: {raw_fastq_dir}', log=FALSE)    
    blue_message('log_file: {log_file}', log=FALSE)   

    temp_dir <- tempdir()    
    dir_create(batch_dir)    

    config_file_dropbox <- glue('scMethDB/config/{plate}_index.yaml')
    config_file_raw <- paste0(temp_dir, glue('/{plate}_index.yaml'))
    
    if (!config_exists(plate)){
        response <- readline(red(glue('Plate config file does not exist. Would you want to automatically create it? (Y/N)')))
        if (response == 'Y'){
            create_config(plate, b_metadata)            
        } else {
            stop(glue('Please make sure to create {config_file_dropbox} and try again'))
        }        
    }
    cfg <- drop_read_yaml(config_file_dropbox)
    
    if (!has_name(cfg, 'genome')){
        cfg$genome <- b_metadata$genome[1]        
        yaml::write_yaml(cfg, config_file_raw)         
        drop_upload(config_file_raw, path = dirname(config_file_dropbox))        
    }

    if (!has_name(cfg, 'annotations')){        
        cfg$annotations <- b_metadata %>% distinct(cell_source, cell_type, treatment) %>% as.list()
        yaml::write_yaml(cfg, config_file_raw) 
        drop_upload(config_file_raw, path = dirname(config_file_dropbox))        
    }

    yaml::write_yaml(cfg, config_file_raw) 
    config_file <- glue('{batch_dir}/{plate}/config.yaml')
    
    if (!force){
        fastqs_exists <- assert_fastqs_exist(raw_fastq_dir, config_file_raw, b_metadata)

        response <- 'N'
        if (!copy_from_mraid40 && !fastqs_exists){
            response <- readline(red(glue('Fastq files do not exists (or are empty). Would you want to copy them from mraid40? (Y/N)')))
            if (response != 'Y'){            
                stop(glue('Please make sure that there are fastq files at: {raw_fastq_dir}. See vignette for the directory structure'))                
            }
        }

        if (copy_from_mraid40 || response == 'Y'){
            loginfo('copying files from mraid40 to mraid14')
            import_to_raid( run_date , config_file_raw, b_metadata) 
        }

        stopifnot(assert_fastqs_exist(raw_fastq_dir, config_file_raw, b_metadata))
    }
    
    # Get indexes and defaults files from dropbox    
    assert_layout_exists(indexes_version)
    drop_download(glue('scMethDB/layouts/{indexes_version}.yaml'), temp_dir, overwrite = TRUE, verbose=FALSE)
    index_file <- glue('{temp_dir}/{indexes_version}.yaml')

    assert_defaults_exists(env_name = 'mcluster04')
    drop_download('scMethDB/env_config/mcluster04.yaml', temp_dir, overwrite = TRUE, verbose=FALSE)
    defaults_file <- glue('{temp_dir}/mcluster04.yaml')
        
    # run pipeline    
    curwd <- getwd()
    on.exit(setwd(curwd))
    setwd(batch_dir)
    run_pipe(config_file_raw=config_file_raw, config_file=config_file, indexes_file=index_file, raw_fastq_dir=raw_fastq_dir, defaults_file=defaults_file, log_file=log_file, overwrite=overwrite, regions=regions)

    qc_fn <- glue('{batch_dir}/{plate}/qc.png')
    fs::file_copy(qc_fn, glue('{db_dir}/qc/batches/{batch}_qc.png'), overwrite=TRUE)
    rdrop2::drop_upload(glue('{db_dir}/qc/batches/{batch}_qc.png'), 'scMethDB/qc/batches', mode='overwrite', verbose=FALSE)

    # if (!is.null(regions)){
    #     qc_capture_fn <- glue('{batch_dir}/{plate}/qc_capture.png')
    #     fs::file_copy(qc_capture_fn, glue('{db_dir}/qc/batches/{batch}_qc_capture.png'), overwrite=TRUE)
    #     rdrop2::drop_upload(glue('{db_dir}/qc/batches/{batch}_qc_capture.png'), 'scMethDB/qc/batches', mode='overwrite', verbose=FALSE)        
    # }
    
    if (!is.null(email)){
        send_finish_email(email, batch, plate, run_date, indexes_version, batch_dir, raw_fastq_dir, log_file)
    }    
}

run_pipe <- function(config_file_raw, config_file, raw_fastq_dir, indexes_file, defaults_file, log_file, overwrite, regions){
    sc5mc::sc5mc.init_pipeline(config_file=config_file_raw, indexes_file=indexes_file, log_file=log_file) 

    #TODO need to remove empty batches    
    sc5mc::sc5mc.run_pipeline(config_file=config_file, raw_fastq_dir=raw_fastq_dir, defaults_file=defaults_file, log_file=log_file, overwrite=overwrite, regions=regions)    
    
}

create_config <- function(plate, batch_metadata){
    if (any(is.na(batch_metadata$illumina_index))){
        stop('Please make sure to fill all the illumina indexes')
    }
    if (any(is.na(batch_metadata$pbat2_index))){
        stop('Please make sure to fill all the pbat2 indexes')
    }

    if (any(is.na(batch_metadata$genome))){
        stop('Please make sure to set the genome field')
    }

    if (any(is.na(batch_metadata$seq_batch_id))){
        stop('Please make sure to set the seq_id field')
    }
    
    amp_batches <- paste0('batch', stringr::str_extract(unique(batch_metadata$amp_batch_id), '([1-4])$'))
    exp_indexes <- map(1:length(amp_batches), ~ c(batch_metadata$pbat2_index[.x], batch_metadata$illumina_index[.x])) %>% set_names(amp_batches)

    # exp_indexes <- map(1:4, ~ c(batch_metadata$pbat2_index[.x], batch_metadata$illumina_index[.x])) %>% set_names(paste0('batch', 1:4))    
    
    annotations <- batch_metadata %>% distinct(cell_source, cell_type, treatment) %>% as.list()

    cfg <- list(experiment = batch_metadata$experiment_ID[1], 
                plate_id = plate,
                seq_id = batch_metadata$seq_batch_id[1], 
                description = batch_metadata$description[1],
                exp_indexes = exp_indexes, 
                genome = batch_metadata$genome[1], 
                annotations = annotations)

    temp_dir <- tempdir()    
    config_file_dropbox <- glue('scMethDB/config/{plate}_index.yaml')
    config_file_raw <- paste0(temp_dir, glue('/{plate}_index.yaml'))
    
    yaml::write_yaml(cfg, config_file_raw) 
    drop_upload(config_file_raw, path = dirname(config_file_dropbox))     
    red_message('created {config_file_dropbox}', log=FALSE)    
}


get_stats_message <- function(stats){
    summary_stats <- stats %>% 
        mutate(empty = empty | cg_num < 1000) %>%                         
        summarise(cpg_per_read = mean(cg_num[!empty] / total_reads[!empty], na.rm=TRUE), total_reads_non_empty = sum(total_reads[!empty], na.rm=TRUE), total_reads = sum(total_reads, na.rm=TRUE), frac_empty = sum(empty, na.rm=TRUE) / n(), num_cells = sum(!empty, na.rm=TRUE), reads_per_cell = total_reads_non_empty / num_cells)

    msg <- glue('                
                <b>Summary stats:</b>
                Total number of reads: <b><mark>{scales::comma(summary_stats$total_reads)}</mark></b>
                <b><mark>{scales::percent(summary_stats$frac_empty)}</mark></b> of the wells are empty (< 1000 CpGs).
                <b><mark>{summary_stats$num_cells}</mark></b> cells have more than 1000 CpGs.
                <b><mark>{round(summary_stats$cpg_per_read, digits=2)}</mark></b> CpGs per read (in non-empty cells). 
                <b><mark>{scales::comma(summary_stats$reads_per_cell)}</mark></b> reads per (non-empty) cell.
                ')
    return(msg)
}

#' Send batch pipeline finish email
#' 
#' @param to vector of email addresses to which the pipeline would send the email
#' @param batch batch id (should correspond to one or more lines of 'scMethDB/scPBAT_annotation.xlsx' in the dropbox) 
#' 
#' @return None
#' 
#' @examples 
#' \dontrun{
#' send_finish_email('my_email@weizmann.ac.il', 'BATCH888')
#' }
#' 
#' @inheritParams run_pipe_batch
#' @export
send_finish_email <- function(to, batch, plate=NULL, run_date=NULL, indexes_version=NULL, batch_dir=NULL, raw_fastq_dir=NULL, log_file=NULL, db_dir=tgconfig::get_param('db_dir', package='tgcg'), fastq_db_dir = tgconfig::get_param('fastq_db_dir', package='tgcg')){
    from <- glue('{Sys.info()[7]}@weizmann.ac.il')
    subj <- glue('sc5mc pipeline finished ({batch})')

    batch_metadata <- get_batch_metadata()
    b_metadata <- batch_metadata %>% filter(batch == !! batch)       

    plate <- plate %||% b_metadata$plate[1]    
    run_date <- run_date %||% gsub('nextseq_', '', b_metadata$seq_batch_id[1])    
    indexes_version <- indexes_version %||% b_metadata$indexes_layout[1]
    batch_dir <- batch_dir %||% glue('{db_dir}/batches/{batch}')
    raw_fastq_dir <-  raw_fastq_dir %||% glue('{fastq_db_dir}/{run_date}')
    log_file <- log_file %||% glue('{batch_dir}/log')

    stats <- fread(glue('{batch_dir}/{plate}/sparse_matrices/{plate}/smat_stats.tsv'))     
    stats_msg <- get_stats_message(stats)
    
    amp_batches_str <- paste("amp_batches:<b><mark>", paste(unique(b_metadata$amp_batch_id), collapse=', '), "</mark></b>")
    body <- glue('<html><div style="white-space: pre">                
                Pipeline finished. QC report is attached.

                Get the reads by running the following commands (in R):

                library(sc5mc)
                library(tgcg)
                scmat <- get_batch_data("{batch}")

                {stats_msg}

                <b>Batch metadata:</b>
                batch: <b><mark>{batch}</mark></b>
                plate: <b><mark>{plate}</mark></b>
                run_date: <b><mark>{run_date}</mark></b>
                indexes_layout: <b><mark>{indexes_version}</mark></b>
                {amp_batches_str}
                output_dir: <b><mark>{batch_dir}</mark></b>
                raw_fastq_dir: <b><mark>{raw_fastq_dir}</mark></b>
                log_file: <b><mark>{log_file}</mark></b>

                <div style="white-space: pre">
                </html>')
    
    temp_dir <- tempdir()    
    data.table::fwrite(stats, glue('{temp_dir}/qc_stats.csv'))    
    attach.files <- c(glue('{batch_dir}/{plate}/qc.png'), glue('{temp_dir}/qc_stats.csv'))
    
    mailR::send.mail(from=as.character(from), to=to, subject=as.character(subj), body=body, attach.files=attach.files, smtp=list(host.name='localhost', port=25), html=TRUE)    
    red_message(paste0('sent email to: ', paste(to, collapse = ', ')))    
}

#' Remove data of a previously created batch
#' 
#' @param batch batch_id
#' @param db_dir directory of the database in which to process the batch - do not change manually. 
#' 
#' @return None
#' @examples 
#' \dontrun{
#' remove_batch('BATCH888')
#' }
#' 
#' @export
remove_batch <- function(batch, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    batch_dir <- glue('{db_dir}/batches/{batch}')
    if (dir_rw(batch_dir)){
        stop(glue('batch {batch} does not exists'))
    }
    response <- readline(red(glue('Would you like to delete {batch} (this cannot be undone)? (Y/N)')))
    if (response == 'Y'){
        if (fs::dir_exists(batch_dir)){
            fs::dir_delete(batch_dir)
        }
    }
}

#' Remove data of a previously created plate
#' 
#' @param plate plate_id
#' @param db_dir directory of the database in which to process the batch - do not change manually. 
#' 
#' @return None
#' @examples 
#' \dontrun{
#' remove_plate('PZM000dummy')
#' }
#' 
#' @export
remove_plate <- function(plate, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    plate_dir <- glue('{db_dir}/plates/{plate}')
    if (!dir_rw(plate_dir)){
        stop(glue('plate {plate} does not exists (or there is no read and write permissions to access it'))
    }
    response <- readline(red(glue('Would you like to delete {plate} (this cannot be undone)? (Y/N)')))
    if (response == 'Y'){
        if (fs::dir_exists(plate_dir)){
            fs::dir_delete(plate_dir)
        }
        if (fs::link_exists(plate_dir)){
            fs::link_delete(plate_dir)
        }
    }
}


#' Merge data from one or more batches of the same plate
#' 
#' @param plate plate id (should correspond to one or more lines of 'scMethDB/scPBAT_annotation.xlsx' in the dropbox) 
#' @param db_dir directory of the database in which to process the batch - do not change manually. #' 
#' @param email vector of email addresses to which the pipeline would send an email once finished.
#' @param batches merge only specific batches
#' @param force do not ask whether to remove old directories
#' 
#' @return None
#' @examples 
#' \dontrun{
#' merge_batches('PZM000dummy', email='my_email@weizmann.ac.il')
#' }
#' 
#' @export
merge_batches <- function(plate, db_dir=tgconfig::get_param('db_dir', package='tgcg'), email=NULL, batches=NULL, force=FALSE){

    batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    db_batches <- batch_metadata %>% filter(plate == !! plate) %>% distinct(batch, plate)
    if (!is.null(batches)){
        if (!(all(batches %in% db_batches$batch))){
            stop(glue('some batches are not of plate {plate}'))
        }
        batches <- db_batches %>% filter(batch %in% batches)
    } else {
        batches <- db_batches
    }

    new_plate_dir <- glue('{db_dir}/plates/{plate}')
    
    if (nrow(batches) == 1){
        batch <- batches$batch[1]        
        batch_dir <- glue('../batches/{batch}')                
        plate_dir <- glue('{batch_dir}/{plate}')        
        link_create(plate_dir, new_plate_dir, symbolic=TRUE)
        log_file <- glue('{db_dir}/plates/{plate}/log')
    } else {
        
        if (dir_exists(new_plate_dir) || link_exists(new_plate_dir)){
            response <- 'N'    
            if (!force){
                response <- readline(red(glue('Plate directory exists. Would you like to remove it? (Y/N)')))    
            }            
            if (response == 'Y'){
                red_message('deleting {new_plate_dir}', log=FALSE)
                if (link_exists(new_plate_dir)){
                    link_delete(new_plate_dir)
                } else {
                    dir_delete(new_plate_dir)                    
                }    
                
            } else {
                msg <- glue('WARNING: older files may corrupt some of the QC statistics. Please make sure to remove old files manually (from {new_plate_dir}) before running QC report')
                red_message(glue('{msg}'))
                warning(msg)
            }
            
        }  

        config_fns <- glue('{db_dir}/batches/{batches$batch}/{plate}/config.yaml')
        stopifnot(all(file.exists(config_fns))) 
        log_file <- glue('{db_dir}/plates/{plate}/log')
        red_message('starting the pipeline', log=FALSE)

        sc5mc::sc5mc.init_merge_pipeline(config_files=config_fns, workdir=glue('{db_dir}/plates'), log_file=log_file)
        sc5mc::sc5mc.run_pipeline(config_file=glue('{db_dir}/plates/{plate}/config.yaml'), log_file=log_file)

        md <- batch_metadata %>% filter(plate == !! plate) %>% distinct(cell_type, cell_source, treatment)
        if (nrow(md) > 1){
            stop('more than a single metadata line for plate, please make sure there is no typo')
        }
        # cell_metadata_fn <- glue('plates/{plate}/sparse_matrices/{plate}/smat_cell_metadata.tsv')         
    }
    plate_dir <- glue('{db_dir}/plates/{plate}')
    qc_fn <- glue('{plate_dir}/qc.png')
    fs::file_copy(qc_fn, glue('{db_dir}/qc/plates/{plate}_qc.png'), overwrite=TRUE)
    rdrop2::drop_upload(glue('{db_dir}/qc/plates/{plate}_qc.png'), 'scMethDB/qc/plates', mode='overwrite', verbose=FALSE)    

    if (!is.null(email)){
        send_finish_email_merge_pipeline(email, plate, log_file, db_dir)
    }        

    if (has_index_sort(plate)){
        add_index_sort_to_plate_metadata(plate)
    }
}


#' Send end of the pipeline email of merge data from one or more batches of the same plate
#' 
#' @param to vector of email addresses to which the pipeline would send an email once finished.
#' @param plate plate id (should correspond to one or more lines of 'scMethDB/scPBAT_annotation.xlsx' in the dropbox) 
#' @param log_file log file
#' @param db_dir directory of the database in which to process the batch - do not change manually. 
#' 
#' @return None
#' @examples 
#' \dontrun{
#' send_finish_email_merge_pipeline('my_email@weizmann.ac.il', 'PZM000dummy')
#' }
#' 
#' @export
send_finish_email_merge_pipeline <- function(to, plate, log_file=NULL, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    from <- glue('{Sys.info()[7]}@weizmann.ac.il')
    subj <- glue('sc5mc (merge) pipeline finished ({plate})')           
    log_file <- log_file %||% glue('{db_dir}/plates/{plate}/log')
    
    batch_metadata <- get_batch_metadata()
    p_metadata <- batch_metadata %>% filter(plate == !! plate)
    batches_str <- paste("batches:<b><mark>", paste(unique(p_metadata$batch), collapse=', '), '</mark></b>')
    amp_batches_str <- paste("amp_batches:<b><mark>", paste(unique(p_metadata$amp_batch_id), collapse=', '), '</mark></b>')
    run_dates_str <- paste("seq batches:<b><mark>", paste(gsub('nextseq_', '', unique(p_metadata$seq_batch_id)), collapse=', '), '</mark></b>')
    indexes_version <- p_metadata$indexes_layout[1]
    plate_dir <- glue('{db_dir}/plates/{plate}')
    stats <- fread(glue('{plate_dir}/sparse_matrices/{plate}/smat_stats.tsv'))

    stats_msg <- get_stats_message(stats)

    body <- glue('<html><div style="white-space: pre">     
                (merge) Pipeline finished. QC report is attached.

                Get the reads by running the following commands (in R):

                library(sc5mc)
                library(tgcg)
                scmat <- get_plate_data("{plate}")

                {stats_msg}

                <b>Plate metadata</b>:
                plate: <b><mark>{plate}</mark></b>
                {batches_str}
                {amp_batches_str}
                {run_dates_str}                                
                indexes_layout: <mark><b>{indexes_version}</mark></b>
                output_dir: <mark><b>{plate_dir}</mark></b>
                log_file: <mark><b>{log_file}</mark></b>

                <div style="white-space: pre">
                </html>')

    temp_dir <- tempdir()    
    data.table::fwrite(stats, glue('{temp_dir}/qc_stats.csv'))    
    attach.files <- c(glue('{plate_dir}/qc.png'), glue('{temp_dir}/qc_stats.csv'))
    
    mailR::send.mail(from=as.character(from), to=to, subject=as.character(subj), body=body, attach.files=attach.files, smtp=list(host.name='localhost', port=25), html=TRUE)    
    red_message(paste0('sent email to: ', paste(to, collapse = ', ')))    
}

wait_for_run_completion <- function(run_dir){
    status_csv <- glue('{run_dir}/demultiplexing_stats.csv')
    sleep_time <- 1
    notify <- TRUE
    
    while(!fs::file_exists(status_csv)){
        if (notify){
            blue_message("Waiting for run completion ({run_dir})", log=FALSE)
            notify <- FALSE
        }    

        Sys.sleep(sleep_time)
        if(sleep_time < 60){
            sleep_time <- sleep_time + 1
        }
    }
    red_message("Run complete", log=FALSE)    
}

#' Run the pipeline on every batch from a sequencing run
#' 
#' @param seq_batch sequencing batch id. Should be the same as in the configuration table in the dropbox.
#' 
#' @return None
#' @examples 
#' \dontrun{
#' run_pipe_seq_batch('nextseq_20180510', copy_from_mraid40=TRUE, email = 'my_email@weizmann.ac.il')
#' }
#' 
#' @inheritParams run_pipe_batch
#' 
#' @export
run_pipe_seq_batch <- function(seq_batch, db_dir=tgconfig::get_param('db_dir', package='tgcg'), fastq_db_dir = tgconfig::get_param('fastq_db_dir', package='tgcg'), copy_from_mraid40=FALSE, email=NULL, overwrite=FALSE){
    batch_metadata <- get_batch_metadata()
    batches <- batch_metadata %>% filter(seq_batch_id == seq_batch) %>% distinct(batch) %>% pull(batch)
    if (length(batches) == 0){
        stop(glue('No batches found from sequencing run: {seq_batch}. Please make sure that you filled the configuration table and that you do not have a typo in "{seq_batch}".'))
    }
    blue_message(paste0('batches: ', paste(batches, collapse = ', ')), log=FALSE)
    run_date <- gsub('nextseq_', '', seq_batch)
    run_dir <- glue(tgconfig::get_param('mraid40_dir', package='tgcg'))
    wait_for_run_completion(run_dir)

    for (batch in batches){
        red_message('doing {batch}', log=FALSE)
        run_pipe_batch(batch, db_dir=db_dir, fastq_db_dir=fastq_db_dir, copy_from_mraid40=copy_from_mraid40, email=email, overwrite=overwrite)
    }

    red_message('completed all batches', log=FALSE) 
}


#' get data of single cell methylation batch
#' 
#' @param batch batch id
#' @param db_dir directory of the database in which to process the batch - do not change manually. 
#' 
#' @return smat object with the batch data
#' @examples 
#' \dontrun{
#' library(sc5mc)
#' scmat <- get_batch_data('BATCH888')
#' }
#' 
#' @export
get_batch_data <- function(batch, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    batch_dir <- glue('{db_dir}/batches/{batch}')
    if (!dir.exists(batch_dir)){
        stop(glue('batch {batch} does not exists'))
    }
    plate <- get_batch_metadata() %>% filter(batch == !! batch) %>% slice(1) %>% pull(plate)
    scmat <- sc5mc::smat.load(glue("{batch_dir}/{plate}/sc_data/smat"))
    return(scmat)
}

#' get data of single cell methylation plate
#' 
#' @param plate  plate id
#' @param db_dir directory of the database in which to process the batch - do not change manually. 
#' 
#' @return smat object with the plate data
#' @examples 
#' \dontrun{
#' library(sc5mc)
#' scmat <- get_plate_data('PZM000dummy')
#' }
#' 
#' @export
get_plate_data <- function(plate, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    smat_path <- get_plate_smat_path(plate, db_dir)
   
    scmat <- sc5mc::smat.load(smat_path)
    return(scmat)
}

get_plate_smat_path <- function(plate, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    plate_dir <- glue('{db_dir}/plates/{plate}')
    if (!dir_rw(plate_dir)){
        stop(glue('batch {plate} does not exists'))
    }

    return(glue("{plate_dir}/sc_data/smat"))
}

#' Get batch statistics
#' 
#' @return tibble with the batch statistics
#' 
#' @examples 
#' \dontrun{
#' get_batch_stats('BATCH888')
#' }
#' 
#' @inheritParams get_batch_data
#' @export
get_batch_stats <- function(batch, db_dir=tgconfig::get_param('db_dir', package='tgcg'), batch_metadata=NULL){
    batch_dir <- glue('{db_dir}/batches/{batch}')
    if (!dir_rw(batch_dir)){
        stop(glue('batch {batch} does not exists'))
    }
    if (is.null(batch_metadata)){
        batch_metadata <- get_batch_metadata()
    }
    plate <- batch_metadata %>% filter(batch == !! batch) %>% slice(1) %>% pull(plate)

    stats <- fread(glue('{batch_dir}/{plate}/sparse_matrices/{plate}/smat_stats.tsv')) %>% as_tibble()
    return(stats)
}

#' Get plate statistics
#' 
#' @return tibble with the plate statistics
#' 
#' @examples 
#' \dontrun{
#' get_plate_stats('PZM000dummy')
#' }
#' 
#' @inheritParams get_plate_data
#' @export
get_plate_stats <- function(plate, db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    plate_dir <- glue('{db_dir}/plates/{plate}')

    if (!dir_rw(plate_dir)){
        stop(glue('plate {plate} does not exists'))
    }

    stats <- fread(glue('{plate_dir}/sparse_matrices/{plate}/smat_stats.tsv')) %>% as_tibble()
    return(stats)
}

#' Get statistics for all batches
#' 
#' @return tibble with statistics for all the batches
#' 
#' @examples 
#' \dontrun{
#' get_all_batch_stats()
#' }
#' 
#' @inheritParams get_batch_data
#' @export
get_all_batch_stats <- function(db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    batch_metadata <- get_batch_metadata()
    
    stats <- plyr::adply(batch_metadata$batch, 1, function(.x) get_batch_stats(.x, db_dir, batch_metadata=batch_metadata), .parallel = TRUE) %>% select(-X1) %>% as_tibble()
    return(stats)
}

#' Get statistics for all plates
#' 
#' @return tibble with statistics for all the plates
#' 
#' @examples 
#' \dontrun{
#' get_all_plate_stats()
#' }
#' 
#' @inheritParams get_plate_data
#' @export
get_all_plate_stats <- function(db_dir=tgconfig::get_param('db_dir', package='tgcg')){
    batch_metadata <- get_batch_metadata()
    stats <- plyr::adply(batch_metadata$plate, 1, function(.x) get_plate_stats(.x, db_dir), .parallel = TRUE) %>% select(-X1) %>% as_tibble()    
    return(stats)
}