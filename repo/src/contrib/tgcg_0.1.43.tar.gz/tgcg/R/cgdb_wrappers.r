cg_dbs <- new.env()
plp_dbs <- new.env()

load_genome_cgdb <- function(genome, env_name='mcluster04'){
	config_file <- glue('scMethDB/env_config/{env_name}.yaml')
	cfg <- drop_read_yaml('scMethDB/env_config/mcluster04.yaml')
	
	if (!has_name(cfg$genomes, genome)){
		stop(glue('{genome} does not exist in {config_file}'))
	}

	red_message('Loading CG database for {genome}', log=FALSE)
	cgdb_path <- cfg$genomes[[genome]]$cgdb	
	cg_dbs[[genome]] <- sc5mc::cgdb_load(cgdb_path)
	invisible(cg_dbs[[genome]])
}

#' Get cgdb of a specific genome
#' 
#' @param genome 'hg19' or 'mm9'
#' @param reload_from_disk reload from disk
#' 
#' @return cgdb object 
#' @examples 
#' \dontrun{
#' db <- get_cgdb('hg19')
#' }
#' 
#' @export
get_cgdb <- function(genome, reload_from_disk=FALSE){	
	if (is.null(cg_dbs[[genome]]) || reload_from_disk){
		load_genome_cgdb(genome)
	} 

	cg_dbs[[genome]]
}

load_genome_plpdb <- function(genome, env_name='mcluster04'){
	config_file <- glue('scMethDB/env_config/{env_name}.yaml')
	cfg <- drop_read_yaml('scMethDB/env_config/mcluster04.yaml')
	
	if (!has_name(cfg$genomes, genome)){
		stop(glue('{genome} does not exist in {config_file}'))
	}

	red_message('Loading pileup database for {genome}', log=FALSE)
	plpdb_path <- cfg$genomes[[genome]]$plpdb	
	gsetroot(cfg$genomes[[genome]]$groot)
	plp_dbs[[genome]] <- sc5mc::plpdb_load(plpdb_path)
	invisible(plp_dbs[[genome]])
}

#' Get plpdb of a specific genome
#' 
#' @param genome 'hg19' or 'mm9'
#' @param reload_from_disk reload from disk
#' 
#' @return cgdb object 
#' @examples 
#' \dontrun{
#' db <- get_plpdb('hg19')
#' }
#' 
#' @export
get_plpdb <- function(genome, reload_from_disk=FALSE){	
	if (is.null(plp_dbs[[genome]]) || reload_from_disk){
		load_genome_plpdb(genome)
	} 

	plp_dbs[[genome]]
}


#' add plate to cgdb
#' 
#' Would remove any older data from the plate 
#' 
#' @param plate  plate id
#' 
#' @return (invisibly) cgdb object with the added plate
#' @examples 
#' \dontrun{
#' add_plate_to_cgdb('PZM00051')
#' }
#' 
#' @export
add_plate_to_cgdb <- function(plate){
	batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    md <- batch_metadata %>% filter(plate == !! plate)
    genome <- md$genome[1]

	db <- get_cgdb(genome)
	sm_data <- get_plate_data(plate)

	if (plate %in% db@cells$plate){
		red_message('removing old cells of {plate} from cgdb')
		db <- sc5mc::cgdb_remove_plate(db, plate)
		cg_dbs[[genome]] <- db
	}

	db <- sc5mc::cgdb_add_plate(db, sm_data, update_cells=TRUE, verbose=FALSE)
	
	cg_dbs[[genome]] <- db
	invisible(db)	
}

#' remove a plate from cgdb
#' 
#' 
#' @param plate  plate id
#' 
#' @return (invisibly) cgdb object without the removed plate
#' 
#' @examples 
#' \dontrun{
#' remove_plate_from_cgdb('PZM00051')
#' }
#' 
#' @export
remove_plate_from_cgdb <- function(plate){
	batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    md <- batch_metadata %>% filter(plate == !! plate)
    genome <- md$genome[1]

	db <- get_cgdb(genome)
	db <- sc5mc::cgdb_remove_plate(db, plate)
	cg_dbs[[genome]] <- db
	invisible(db)
}

#' add plate to pileup db
#' 
#' Would remove any older data from the plate 
#' 
#' @param plate  plate id
#' 
#' @return (invisibly) plpdb object with the added plate
#' @examples 
#' \dontrun{
#' add_plate_to_plpdb('PZM00051')
#' }
#' 
#' @export
add_plate_to_plpdb <- function(plate, update_cells=TRUE){
	batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    md <- batch_metadata %>% filter(plate == !! plate)
    genome <- md$genome[1]

	db <- get_plpdb(genome)
	smat_path <- get_plate_smat_path(plate)	

	if (plate %in% db@cells$plate){
		red_message('removing old cells of {plate} from cgdb')
		db <- sc5mc::cgdb_remove_plate(db, plate)
		plp_dbs[[genome]] <- db
	}

	db <- sc5mc::plpdb_add_plate(db, smat_path, update_cells=update_cells, verbose=FALSE)
	plp_dbs[[genome]] <- db
	invisible(db)	
}

#' remove a plate from pileup db
#' 
#' 
#' @param plate plate id
#' 
#' @return (invisibly) plpdb object without the removed plate
#' 
#' @examples 
#' \dontrun{
#' remove_plate_from_plpdb('PZM00051')
#' }
#' 
#' @export
remove_plate_from_plpdb <- function(plate){
	batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    md <- batch_metadata %>% filter(plate == !! plate)
    genome <- md$genome[1]

	db <- get_plpdb(genome)
	db <- sc5mc::cgdb_remove_plate(db, plate)
	plp_dbs[[genome]] <- db
	invisible(db)
}