.onLoad <- function(libname, pkgname) {        
    options(tgutil.verbose = TRUE, tgutil.cache = TRUE)
}