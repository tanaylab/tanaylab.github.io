import_to_raid <- function(run_date, config_fn, batch_metadata, mraid40_dir = glue(tgconfig::get_param('mraid40_dir', package='tgcg')), mraid14_dir = glue(tgconfig::get_param('mraid14_dir', package='tgcg')), overwrite=TRUE){

    if (!assert_fastqs_exist(mraid40_dir, config_fn, batch_metadata)){
        stop(glue('Files do not exist on {mraid40_dir}. Please make sure that the run date ("{run_date}") is correct in the excel metadata file'))
    }
    
    loginfo('creating mraid14 dir: %s', mraid14_dir)
    fs::dir_create(mraid14_dir)

    amp_batches <- paste0('batch', stringr::str_extract(unique(batch_metadata$amp_batch_id), '([1-4])$'))
    illu_indexes <- map_chr(yaml::read_yaml(config_fn)[['exp_indexes']][amp_batches], ~ .x[2]) %>% unique()      
    loginfo('illumina indexes: %s', paste(illu_indexes, collapse = ', '))
    
    if (overwrite){     
        walk(illu_indexes, ~ safely(fs::dir_delete)(glue('{mraid14_dir}/{.x}')))
    }

    existing_dirs <- dir_rw(map_chr(illu_indexes, ~  fs::path_join(c(mraid14_dir, .x))))
    
    if (any(existing_dirs)){
            logwarn('skipping the following illuimna indexes that were already copied: %s', paste(illu_indexes[existing_dirs], collapse = ', '))
    } 

    if (any(!existing_dirs)){
            loginfo('copying the following illumina indexes: %s', paste(illu_indexes[!existing_dirs], collapse = ', '))
    }   

    walk(illu_indexes[!existing_dirs], ~ dir_copy_or_link(fs::path_join(c(mraid40_dir, .x)), fs::path_join(c(mraid14_dir, .x))))
    
    
    arrange_raw_files(illu_indexes, mraid14_dir)
}

arrange_raw_files <- function(illu_indexes, mraid14_dir){
    for (idx in illu_indexes){
        path <- fs::path_join(c(mraid14_dir, idx) )
        raw_dir <- fs::path_join(c(path, 'raw'))
        fs::dir_create(raw_dir)         
        walk(dir_ls(path, regexp='.+fastq.gz$'), ~ fs::file_move(.x, fs::path_join(c(raw_dir, basename(.x)))))
    }   
}


assert_fastqs_exist <- function(fastq_dir, config_fn, batch_metadata){
    amp_batches <- paste0('batch', stringr::str_extract(unique(batch_metadata$amp_batch_id), '([1-4])$'))
    illu_indexes <- map_chr(yaml::read_yaml(config_fn)[['exp_indexes']][amp_batches], ~ .x[2]) %>% unique()      
        
    if (!dir_r(fastq_dir)){
        return(FALSE)
    }
    
    if (!all(illu_indexes %in% basename(fs::dir_ls(fastq_dir) ))){
        return(FALSE)
    }

    fastq_files <- map_df(illu_indexes, ~ fs::dir_info(glue('{fastq_dir}/{.x}'), regexp='*.fastq.gz$') %>% select(path, size) %>% mutate(illumina = .x))
    fastq_files <- bind_rows(fastq_files, map_df(illu_indexes, ~ {
        nfo <- possibly(fs::dir_info, NULL)(glue('{fastq_dir}/{.x}/raw'), regexp='*.fastq.gz$')
        if (!is.null(nfo)){
            nfo <- nfo %>% select(path, size) %>% mutate(illumina = .x)
        }
        return(nfo)     
    }))
    n_illumina <- fastq_files %>% filter(size > 0) %>% distinct(illumina) %>% nrow()
    if (n_illumina < length(illu_indexes)){
        return(FALSE)
    }   

    return(TRUE)        
}
