## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(tidyverse)
library(sc5mc)

## ---- eval=FALSE---------------------------------------------------------
#  install.packages('tgcg', repos=c(getOption('repos'), 'https://tanaylab.bitbucket.io/repo'))

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github("r-lib/fs")

## ---- eval=TRUE----------------------------------------------------------
library(gpatterns)
library(sc5mc)
library(tgcg)
library(tidyverse) # Load the tidyverse packages 

## ---- eval=FALSE---------------------------------------------------------
#  library(tgcg)
#  run_pipe_batch('BATCH888', email = 'my_email@weizmann.ac.il')

## ------------------------------------------------------------------------
library(tgcg)
metadata <- get_batch_metadata()
metadata %>% 
  filter(batch == 'BATCH888') %>% 
  select(batch, plate, indexes_layout, cell_source, cell_type, treatment, amp_batch_id, batch_num, seq_batch_id, genome) %>% 
  knitr::kable('html') %>% 
  kableExtra::kable_styling(bootstrap_options = c("responsive"))

## ---- eval=FALSE---------------------------------------------------------
#  library(tgcg)
#  run_pipe_batch('BATCH888')

## ---- eval=FALSE---------------------------------------------------------
#  library(tgcg)
#  run_pipe_batch('BATCH888', email = c('zoharmukamel@gmail.com', 'amostanay@gmail.com'))

## ---- eval=FALSE---------------------------------------------------------
#  run_pipe_batch('BATCH888', overwrite=TRUE)

## ---- eval=FALSE---------------------------------------------------------
#  run_pipe_batch('BATCH888', overwrite='mapping')

## ---- eval=FALSE---------------------------------------------------------
#  # set the misha root (set to mm9, or any other genome, if needed)
#  gsetroot('/home/aviezerl/hg19')
#  
#  # load the matrices
#  library(sc5mc)
#  scmat <- get_batch_data('BATCH888')

## ---- eval=FALSE---------------------------------------------------------
#  merge_batches('PZM000dummy', email='my_email@weizmann.ac.il')

## ---- eval=FALSE---------------------------------------------------------
#  library(sc5mc)
#  scmat <- get_plate_data('PZM000dummy')

## ---- eval=FALSE---------------------------------------------------------
#  library(tgcg)
#  remove_batch('BATCH888')

## ---- eval=FALSE---------------------------------------------------------
#  library(tgcg)
#  remove_plate('PZM000dummy')

## ------------------------------------------------------------------------
library(tgcg)
metadata <- get_batch_metadata()
metadata

## ---- eval=FALSE---------------------------------------------------------
#  library(tgcg)
#  run_pipe_seq_batch('nextseq_dummy', copy_from_mraid40=TRUE, email = 'my_email@weizmann.ac.il')

## ---- eval=FALSE---------------------------------------------------------
#  add_index_sort_to_plate_metadata('PZM00078')

## ---- eval=FALSE---------------------------------------------------------
#  add_plate_to_cgdb('PZM000dummy')

## ---- eval=FALSE---------------------------------------------------------
#  remove_plate_from_cgdb('PZM000dummy')

## ---- eval=FALSE---------------------------------------------------------
#  db <- get_cgdb('hg19')

## ---- eval=FALSE---------------------------------------------------------
#  db <- get_cgdb('hg19', reload_from_disk=FALSE)

