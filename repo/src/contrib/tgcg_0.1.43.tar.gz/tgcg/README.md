---
output:
  md_document:
    variant: markdown_github
---



# tgcg

The goal of tgcg is to provide infrastructure for processing single cell methylation data in the Tanay Group environment. 

## Installation
Please make sure that you loaded the MKL module: 


```bash
ml load mkl
```

And then run:


```r
install.packages('tgcg', repos=c(getOption('repos'), 'https://tanaylab.bitbucket.io/repo'))
```

## Examples

### Process a new batch 
In order to process a new batch of single cell methylation data fill the configuration table in the dropbox (`'scMethDB/scPBAT_annotation.xlsx'`) and run the following command (assuming you are processing `'BATCH888'`):


```r
library(tgcg)
run_pipe_batch('BATCH888', email='my_email@weizmann.ac.il')
```

### Merge one or more batches
In order to merge data from one or more batches of the same plate run (assuming the plate id is `'PZM000dummy'`):

```r
library(tgcg)
merge_batches('PZM000dummy', email='my_email@weizmann.ac.il')
```

### Load data
In order to load previously processed data run: 

```r
library(sc5mc)
library(tgcg)

# set the misha root (set to mm9, or any other genome, if needed)
gsetroot('/home/aviezerl/hg19')

# load data from batch
scmat <- get_batch_data('BATCH888')

# load data from plate
scmat <- get_plate_data('PZM000dummy')
```

### Remove batches/plates
In order to remove previously processed batch run: 

```r
library(tgcg)
remove_batch('BATCH888')
```

In order to remove previously processed plate run: 

```r
library(tgcg)
remove_plate('PZM000dummy')
```

### Get the current metadata
In order to get the current metadata table run: 

```r
library(tgcg)
metadata <- get_batch_metadata()
```
