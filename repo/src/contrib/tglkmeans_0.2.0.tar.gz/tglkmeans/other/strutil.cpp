#include "strutil.h"
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;


int split_line(BufferedFile &in, vector<string> &fields, char delim, int estimated_num_fields)
{
    int num_lines = 0;
    fields.resize(estimated_num_fields);
    for (vector<string>::iterator istr = fields.begin(); istr != fields.end(); ++istr)
        istr->resize(0);
    vector<string>::iterator istr = fields.begin();
    while (1) {
        int c = in.getc();

        if (in.error()) {
            fields.clear();
            break;
        }

        if (c == '\r')
            continue;

        if (c == '\n' || in.eof()) {
            num_lines++;
            if (istr == fields.begin() && istr->empty()) {
                if (in.eof()) {
                    fields.clear();
                    break;
                }

                // eat up empty lines
                continue;
            }
            fields.resize(istr - fields.begin() + 1);
            break;
        }

        if (c == delim) {
            istr++;
            if (istr == fields.end()) {
                fields.push_back(string());
                istr = fields.begin() + fields.size() - 1;
            }
        } else
            istr->push_back(c);
    }
    return num_lines;
}

int split_line(istream &in, vector<string> &fields, char delim, int estimated_num_fields)
{
    int num_lines = 0;
    fields.resize(estimated_num_fields);
    for (vector<string>::iterator istr = fields.begin(); istr != fields.end(); ++istr)
        istr->resize(0);
    vector<string>::iterator istr = fields.begin();
    while(in) {
        int c = in.get();
        if(c == '\r') {
            continue;
        }

        if (c == '\n')
            num_lines++;

        if (c == '\n' || !in.good()) {
            if (istr == fields.begin() && istr->empty()) {
                if (!in.good()) {
                    fields.clear();
                    break;
                }

                // eat up empty lines
                continue;
            }
            fields.resize(istr - fields.begin() + 1);
            break;
        }
        if (c == delim) {
            istr++;
            if (istr == fields.end()) {
                fields.push_back(string());
                istr = fields.begin() + fields.size() - 1;
            }
        } else
            istr->push_back(c);
    }
    return num_lines;
}

void split_line(const string &s, vector<string> &fields, char delim)
{
    fields.resize(0);
    string field;
    for(string::const_iterator si = s.begin(); si != s.end(); si++){
        if(*si == delim) {
            fields.push_back(field);
            field.resize(0);
        } else {
            field.push_back(*si);
        }
    }
    fields.push_back(field);
}

void split_line(const string &s, vector<float> &fields, char delim)
{
    fields.resize(0);
    string field;
    for(string::const_iterator si = s.begin(); si != s.end(); si++){
        if(*si == delim) {
            float f = atof(field.c_str());
            fields.push_back(f);
            field.resize(0);
        } else {
            field.push_back(*si);
        }
    }
    float f = atof(field.c_str());
    fields.push_back(f);
}

void split_line(const string &s, vector<int> &fields, char delim)
{
    fields.resize(0);
    string field;
    for(string::const_iterator si = s.begin(); si != s.end(); si++){
        if(*si == delim) {
            int v = atoi(field.c_str());
            fields.push_back(v);
            field.resize(0);
        } else {
            field.push_back(*si);
        }
    }
    int v = atoi(field.c_str());
    fields.push_back(v);
}



void read_float_table_with_rowname(istream &in, vector<vector<float> > &data, vector<string> &row_name, int with_header,
                                   int subst_nas, float na_value) {
    vector<string> fields;
    int width = -1;
    if (with_header) {
        split_line(in, fields);
        width = fields.size() - 1;
    }
    int row = 0;
    while ((bool)in) {
        split_line(in, fields);
        if (fields.size() == 0) {
            return;
        }
        if (width == -1) {
            width = fields.size() - 1;
        }

        data.resize(row + 1);
        data[row].resize(width);
        vector<float>::iterator dt = data[row].begin();
        row_name.push_back(fields[0]);
        vector<string>::const_iterator inp = fields.begin() + 1;
        while (inp != fields.end()) {
            char *fin;
            if (*inp == "NA" && subst_nas) {
                *dt = na_value;
            } else {
                *dt = strtof((*inp).c_str(), &fin);
            }
            dt++;
            inp++;
        }
        row++;
    }
}
