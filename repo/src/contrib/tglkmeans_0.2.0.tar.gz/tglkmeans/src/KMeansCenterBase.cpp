//
// Created by aviezerl on 6/5/17.
//

#include "KMeansCenterBase.h"

void KMeansCenterBase::report_meta_data_header(ostream &out)
{
    //do nothing by default
}

void KMeansCenterBase::report_meta_data(ostream &out, const vector<float> &v)
{
    //do nothing by default
}
