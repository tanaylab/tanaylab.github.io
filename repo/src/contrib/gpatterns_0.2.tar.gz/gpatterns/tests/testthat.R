library(testthat)
library(gpatterns)

test_check("gpatterns")

