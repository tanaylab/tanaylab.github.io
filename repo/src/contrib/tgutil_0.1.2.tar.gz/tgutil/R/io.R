########################################################################
#' @export
argpack <- function(...)
{

	args <- list(...)
	arg_names <- sapply(substitute(list(...))[-1], deparse)
	if (is.null(names(args))) {
		names(args) <- arg_names
	} else {
        names(args) <- ifelse((names(args) == ''), arg_names, names(args))
    }

	return(args)
}


########################################################################
#' Wrapper for data.table::fread. Returns a data.frame instead of a data.table
#' @export
#' @inheritDotParams data.table::fread -data.table -key
fread <- function(...) {
	return(data.table::fread(..., data.table=FALSE))
}


########################################################################
#' Use `fread()` to read a csv/tsv with row names (e.g. one created with `write.table()`)
#' @export
#' @param row.var Name of column that will hold row names.
#'                Setting this parameter to NULL will maintain row names as row names.
#' @inheritDotParams data.table::fread -data.table -key -header -skip -col.names
fread_rownames <- function(..., row.var='rowname')
{
	use_rownames = FALSE
	if (is.null(row.var)) {
		use_rownames = TRUE
		row.var = '__rowname__'
	}

	params <- list(...)
	header <- strsplit(readLines(params[[1]], n=1, warn=FALSE), '\t', fixed=TRUE)[[1]]

	params$header = FALSE;
    params$skip = 1;
    params$col.names = c(row.var, header)

	data <- do.call(fread, params)
	if (use_rownames) {
		data <- tibble::column_to_rownames(data, '__rowname__')
	}

	return(data)
}


########################################################################
#' Wrapper for data.table::fwrite
#' @export
#' @inheritParams data.table::fwrite
#' @inheritDotParams data.table::fwrite
fwrite <- function(x, ...) {
	data.table::fwrite(x, na='NA', ...)
}


########################################################################
#' Efficiently write Matrix Market format
#' @export
fwrite_mm <- function(x, fname, sep=' ', row.names=TRUE, col.names=TRUE)
{
	rows <- NULL
	cols <- NULL

	dims <- dim(x)
	if (length(dims) != 2) {
		stop("fwrite_mm() can only write two-dimensional metrices")
	}

	if (!is.null(rownames(x)) && ((row.names==TRUE) || is.character(row.names))) {
		if (row.names==TRUE) {
			row.names <- paste0(fname, '.rownames')
		}
        rows <- tibble(rowname=rownames(x))
        rownames(x) <- NULL
    }

    if (!is.null(colnames(x)) && ((col.names==TRUE) || is.character(col.names))) {
		if (col.names == TRUE) {
			col.names <- paste0(fname, '.colnames')
		}
        cols <- tibble(colname=colnames(x))
        colnames(x) <- NULL
    }

	x <- broom::tidy(x)

	if (any(colnames(x) != c('row', 'column', 'value'))) {
        stop("Failed to convert argumant 'x' into a row-column-value format")
    }
	if (mode(x$column) != 'numeric') {
		stop("fwrite_mm() can only write numerical matrices")
	}

	x <- arrange(x, row, column)

	output <- file(fname, open='w')
	writeLines('%%MatrixMarket matrix coordinate real general', output)
	writeLines(paste(dims[1], dims[2], nrow(x), sep=sep), output)
	close(output)

	fwrite(x, fname, sep=sep, row.names=FALSE, col.names=FALSE, append=TRUE)

	if (!is.null(rows)) {
		fwrite(rows, row.names, row.names=FALSE, col.names=FALSE)
	}
	if (!is.null(cols)) {
		fwrite(cols, col.names, row.names=FALSE, col.names=FALSE)
	}
}


########################################################################
#' Efficiently read Matrix Market format
#' @export
fread_mm <- function(fname, sep=' ', row.names=TRUE, col.names=TRUE)
{
	if (row.names==TRUE) {
		row.names <- paste0(fname, '.rownames')
	}
	if (col.names == TRUE) {
		col.names <- paste0(fname, '.colnames')
	}

	input <- file(fname, open='r')

	header <- readLines(input, n=1, warn=FALSE)
	if (sep == ' ') {
		header <- strsplit(header, ' +')[[1]]
	}
	else {
		header <- strsplit(header, sep, fixed=TRUE)[[1]]
	}
	if (header[1] != '%%MatrixMarket') {
		close(input)
		stop("File does not contain a MatrixMarket header")
	}
	if ((header[2] != 'matrix') || (header[3] != 'coordinate') || (header[5] != 'general')) {
		close(input)
		stop("fread_mm() can only read matrices in general, coordinate format")
	}

	VALUE_TYPES <- c('real'='numeric', 'integer'='integer')
	value_type <- VALUE_TYPES[header[4]]
	names(value_type) <- NULL
	if (is.na(value_type)) {
		close(input)
		stop("File contains an unsupported value type: ", header[4])
	}

	skip <- 1
	while(TRUE) {
		line = readLines(input, n=1, warn=FALSE)
		skip <- skip + 1
		if (!startsWith(line, '%')) {
			break
		}
	}

	if (sep == ' ') {
		dims <- strsplit(line, ' +')[[1]]
	} else {
		dims <- strsplit(line, sep, fixed=TRUE)[[1]]
	}
	dims <- as.numeric(dims)
	if (length(dims) != 3) {
		close(input)
		stop("Could not parse matrix dimenstions line")
	}
	if (any(as.integer(dims) != dims)) {
		close(input)
		stop("Dimensions line contains non-integer values")
	}
	close(input)

	x <- fread(fname, sep=sep, header=FALSE, skip=skip, colClasses=c('integer', 'integer', value_type))
	if (nrow(x) != dims[3]) {
		stop("Number of data lines in file does not match dimensions line")
	}

	x <- Matrix::sparseMatrix(i=x[,1], j=x[,2], x=x[,3], dims=dims[1:2])

	if (file.exists(row.names)) {
        rows <- fread(row.names, sep='\t', header=FALSE)
        rownames(x) <- rows[,1]
    }

    if (file.exists(col.names)) {
        cols <- fread(col.names, sep='\t', header=FALSE)
        colnames(x) <- cols[,1]
    }

	return(x)
}


########################################################################
load_vector <- function(fname)
{
    x <- fread(fname, sep='\t', header=FALSE)
    if (ncol(x) == 1) {
        x <- x[,1]
    }
    else if (ncol(x) == 2) {
        x <- structure(x[,2], names=x[,1])
    }
    else {
        stop("File ", fname, " must have one or two columns")
    }

    return(x)
}


########################################################################
#' Read a numeric vector from a file created by save_numeric
#' @export
load_numeric <- function(fname)
{
    return(as.numeric(read_vector(fname)))
}


########################################################################
#' Read a character vector from a file created by save_character
#' @export
load_character <- function(fname)
{
    return(as.character(read_vector(fname)))
}


########################################################################
#' Read a dataframe from a file created by save_dataframe
#' @export
load_dataframe <- function(fname)
{
    x <- fread(fname, sep='\t', header=TRUE)

    if (colnames(x)[1] == '__rownames__') {
        x <- tibble::column_to_rownames(x, '__rownames__')
    }

    return(x)
}


########################################################################
#' Read a matrix from a file created by save_matrix
#' @export
load_matrix <- function(fname)
{
    x <- fread(fname, sep='\t', header=TRUE)

    if (colnames(x)[1] == '__rownames__') {
        x <- tibble::column_to_rownames(x, '__rownames__')
    }

    x <- as.matrix(x)

    if (all(startsWith(colnames(x), '__null_'))) {
        colnames(x) <- NULL
    }

    return(x)
}


########################################################################
save_vector <- function(x, fname)
{
    stopifnot(is.vector(x))

    if (is.null(names(x))) {
        x <- tibble::tibble(x=x)
    }
    else {
        x <- tibble::tibble(names=names(x), x=x)
    }

    fwrite(x, fname, sep='\t', row.names=FALSE, col.names=FALSE)
}


########################################################################
# Write a numeric vector to a file, preserving cell names.
#' @export
save_numeric <- function(x, fname)
{
    stopifnot(is.numeric(x))
    return(write_vector(x, fname))
}


########################################################################
# Write a character vector to a file, preserving cell names.
#' @export
save_character <- function(x, fname)
{
    stopifnot(is.character(x))
    return(write_vector(x, fname))
}


########################################################################
# Writes a dataframe to a file, preserving row names.
#' @export
save_dataframe <- function(x, fname)
{
    stopifnot(is.data.frame(x))
    if (!is.null(rownames(x)) &&
        !all(rownames(x) == 1:nrow(x))) {
        x <- tibble::rownames_to_column(x, '__rownames__')
    }

    fwrite(x, fname, sep='\t', quote=FALSE, col.names=TRUE, row.names=FALSE)
}


########################################################################
# Writes a matrix to a file, preserving row and column names.
#' @export
save_matrix <- function(x, fname)
{
    stopifnot(is.matrix(x))

    if (is.null(colnames(x))) {
        colnames(x) <- paste0('__null_', 1:ncol(x), '__')
    }

    x <- as.data.frame(x)

    if (!is.null(rownames(x)) && !all(rownames(x) == 1:nrow(x))) {
        x <- tibble::rownames_to_column(x, '__rownames__')
    }

    fwrite(x, fname, sep='\t', col.names=TRUE, row.names=FALSE)
}
