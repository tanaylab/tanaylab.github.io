#' tgconfig.
#'
#' @name tgconfig
#' @docType package
NULL
