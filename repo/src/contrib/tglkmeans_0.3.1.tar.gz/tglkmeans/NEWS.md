# tglkmeans 0.3.1
* Use rownames when exist.
* Do not fail when "id" column doesn't exist (warn instead).

# tglkmeans 0.3.0

* Removed bootstrapping (it was causing a lot of problems in travis testing and almost wasn't used.
* Added a `NEWS.md` file to track changes to the package.
