has_index_sort <- function(plate){
    batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    md <- batch_metadata %>% filter(plate == !! plate)

    index_sort_file <- unique(md$index_sort_file)
    index_sort_file <- index_sort_file[!is.na(index_sort_file)]

    return(length(index_sort_file) > 0)
}

get_plate_index_sort_csv <- function(plate){
    batch_metadata <- get_batch_metadata()
    assert_plate_exists(plate, batch_metadata)
    md <- batch_metadata %>% filter(plate == !! plate)

    index_sort_file <- unique(md$index_sort_file)
    index_sort_file <- index_sort_file[!is.na(index_sort_file)]

    if (length(index_sort_file) == 0){
        stop("Plate doesn't have index sort files, please check the annotations table.")
    }

    if (length(index_sort_file) > 1){
        stop('index_sort_file field contains more than a single file, please check the annotations table.')
    }

    index_sort_file <- glue('scMethDB/index_sort/{index_sort_file}')
    if (!rdrop2::drop_exists(index_sort_file)){
        stop(glue("index sort csv file doesn't exists, please add it to {index_sort_file}"))
    }

    temp_index_fn <- tempfile()    
    drop_download(index_sort_file, temp_index_fn, overwrite = TRUE, verbose=FALSE, progress=FALSE)
    
    idx_sort <- parse_index_sort(temp_index_fn)
    return(idx_sort)
}

parse_index_sort <- function(index_sort_fn){        
    start_line <- fread(glue('grep -n ^Well {index_sort_fn} | cut -d: -f1'))[1] 
    idx_sort <- fread(glue('tail -n +{start_line} {index_sort_fn}')) %>% as.tibble()    
    
    idx_sort <-  idx_sort %>% 
        gather('stat', 'val', -Well) %>% 
        filter(grepl('Mean', stat), grepl('All Events', stat)) %>% 
        filter(!grepl('Geo', stat)) %>%
        mutate(stat = gsub('All Events ', '', stat), 
               stat = gsub(' Mean', '', stat), 
               stat = gsub('[ -]', '_', stat)) %>% 
        mutate(val = as.numeric(gsub(',', '', val))) %>% 
        rename(plate_pos = Well ) %>% 
        spread(stat, val) %>% 
        tidyr::extract(plate_pos, into=c('p1', 'p2'), '(.)(.+)') %>% 
        mutate(plate_pos = paste0(p2, p1)) %>% 
        select(-p1, -p2)
    return(idx_sort)
}

#' add index sort data to plate metadata
#' 
#' 
#' @param plate  plate id
#' 
#' @return None
#' @examples 
#' \dontrun{
#' add_index_sort_to_plate_metadata('PZM00077')
#' }
#' 
#' @export
add_index_sort_to_plate_metadata <- function(plate){
    idx_sort <- get_plate_index_sort_csv(plate)

    smat_path <- get_plate_smat_path(plate)
    cell_metadata_fn <- glue('{smat_path}_cell_metadata.tsv')
    cell_metadata <- fread(cell_metadata_fn)
    
    if (any(colnames(select(idx_sort, -plate_pos)) %in% colnames(cell_metadata))){
        warning('cell_metadata already has index sort data, overwriting')
        cell_metadata <- cell_metadata %>% select(-one_of(colnames(idx_sort)))
    }

    cell_metadata <- cell_metadata %>% left_join(idx_sort, by='plate_pos')
    fwrite(cell_metadata, cell_metadata_fn, sep='\t')
}